---
name: "💡 Feature Request"
about: 'For ideas or feature requests, please make a pull request, or open an issue'
---

This repository is only for reporting bugs or issues. If you need support, please use
other channels:

1. Write an email - mailto:support@krayincrm.com

2. Create support ticket on https://krayincrm.uvdesk.com

3. Visit forums to get support from our community (https://forums.krayincrm.com)

Alternatively, you may use Facebook (https://www.facebook.com/groups/krayincrm/).

We promise that more channels are coming soon!!!