---
name: "🔒 Security Vulnerabilities"
about: 'For reporting security-related issues, see: https://github.com/krayin/laravel-crm#security-vulnerabilities'
---

PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, SEE BELOW.

If you have security vulnerability to address related to Krayin then please write a mail to us:
**support@krayincrm.com**