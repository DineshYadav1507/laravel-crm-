<?php

namespace Webkul\Activity\Contracts;

interface Participant
{
}