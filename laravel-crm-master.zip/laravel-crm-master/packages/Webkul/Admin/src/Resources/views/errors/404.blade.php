@extends('admin::errors.illustrated-layout')

@section('title', __('Page Not Found'))
@section('code', '404')
@section('message', __('We were not able to find the page you are looking for.'))
