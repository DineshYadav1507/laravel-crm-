@extends('admin::errors.illustrated-layout')

@section('title', __('Page Expired'))
@section('code', '419')
@section('message', __('This page is expired.'))
