<?php

namespace Webkul\Core\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CoreConfigProxy extends ModelProxy
{

}