<?php

namespace Webkul\Email\Contracts;

interface Attachment
{
}