<?php
namespace Webkul\Email\Helpers;

class Exception extends \RuntimeException
{

}
