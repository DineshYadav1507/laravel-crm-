<?php

namespace Webkul\Email\Models;

use Konekt\Concord\Proxies\ModelProxy;

class EmailProxy extends ModelProxy
{

}