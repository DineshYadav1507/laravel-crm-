<?php

namespace Webkul\EmailTemplate\Contracts;

interface EmailTemplate
{
}