<?php

namespace Webkul\Lead\Contracts;

interface Lead
{
}