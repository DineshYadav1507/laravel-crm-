<?php

namespace Webkul\Lead\Contracts;

interface Product
{
}