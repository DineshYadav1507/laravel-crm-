<?php

namespace Webkul\Lead\Contracts;

interface Source
{
}