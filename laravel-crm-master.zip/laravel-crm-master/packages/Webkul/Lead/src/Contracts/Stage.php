<?php

namespace Webkul\Lead\Contracts;

interface Stage
{
}