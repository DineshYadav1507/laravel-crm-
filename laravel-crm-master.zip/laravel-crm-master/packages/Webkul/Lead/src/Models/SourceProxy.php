<?php

namespace Webkul\Lead\Models;

use Konekt\Concord\Proxies\ModelProxy;

class SourceProxy extends ModelProxy
{

}