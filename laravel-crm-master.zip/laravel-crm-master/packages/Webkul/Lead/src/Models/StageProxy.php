<?php

namespace Webkul\Lead\Models;

use Konekt\Concord\Proxies\ModelProxy;

class StageProxy extends ModelProxy
{

}