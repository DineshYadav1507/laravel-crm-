<?php

namespace Webkul\Product\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ProductProxy extends ModelProxy
{

}