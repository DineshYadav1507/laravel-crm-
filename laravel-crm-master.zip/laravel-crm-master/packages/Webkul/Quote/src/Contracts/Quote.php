<?php

namespace Webkul\Quote\Contracts;

interface Quote
{
}