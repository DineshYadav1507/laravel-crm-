<?php

namespace Webkul\Quote\Contracts;

interface QuoteItem
{
}