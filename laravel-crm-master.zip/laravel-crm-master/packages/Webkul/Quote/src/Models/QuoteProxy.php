<?php

namespace Webkul\Quote\Models;

use Konekt\Concord\Proxies\ModelProxy;

class QuoteProxy extends ModelProxy
{

}